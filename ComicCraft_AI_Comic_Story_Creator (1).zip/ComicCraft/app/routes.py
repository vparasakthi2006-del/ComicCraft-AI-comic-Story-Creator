from pathlib import Path

from fastapi import APIRouter, Form, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.templating import Jinja2Templates

from app.models import PromptRequest
from app.services.gemini_flash import generate_outline
from app.services.gemini_pro import generate_story
from app.services.image_generator import generate_image
from app.services.layout_builder import build_comic_layout
from app.services.exporters import save_pdf

templates = Jinja2Templates(directory="templates")
router = APIRouter()

def _validate_form(story_prompt, character_name, setting, tone, art_style) -> PromptRequest:
    return PromptRequest(
        story_prompt=story_prompt.strip(),
        character_name=character_name.strip(),
        setting=setting.strip(),
        tone=tone.strip(),
        art_style=art_style.strip(),
    )

def _generate(req: PromptRequest):
    outlines = generate_outline(req)
    stories = generate_story(req, outlines)
    image_paths = [
        generate_image(panel.image_prompt, panel.panel_number)
        for panel in stories
    ]
    layout = build_comic_layout(stories, image_paths)
    title = f"{req.character_name}'s Comic Adventure"
    pdf_path = save_pdf(layout, title)
    return title, layout, pdf_path

@router.get("/")
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@router.post("/generate")
async def generate(
    request: Request,
    story_prompt: str = Form(...),
    character_name: str = Form(...),
    setting: str = Form(...),
    tone: str = Form(...),
    art_style: str = Form(...),
):
    try:
        req = _validate_form(story_prompt, character_name, setting, tone, art_style)
        title, layout, pdf_path = _generate(req)
        return templates.TemplateResponse(
            "comic_preview.html",
            {
                "request": request,
                "title": title,
                "layout": layout,
                "pdf_url": f"/download/{pdf_path.name}",
            },
        )
    except Exception as exc:
        return templates.TemplateResponse(
            "index.html",
            {"request": request, "error": f"Generation failed: {exc}"},
            status_code=500,
        )

@router.post("/generate-comic/json")
async def generate_json(req: PromptRequest):
    try:
        title, layout, pdf_path = _generate(req)
        return JSONResponse({
            "title": title,
            "panels": layout,
            "pdf_url": f"/download/{pdf_path.name}",
        })
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))

@router.get("/download/{filename}")
async def download_pdf(filename: str):
    safe_name = Path(filename).name
    path = Path("static/exports") / safe_name
    if not path.exists() or path.suffix.lower() != ".pdf":
        raise HTTPException(status_code=404, detail="PDF not found")
    return FileResponse(
        path=str(path),
        media_type="application/pdf",
        filename=safe_name,
        headers={"Content-Disposition": f'attachment; filename="{safe_name}"'},
    )

@router.get("/export-success")
async def export_success(request: Request):
    return templates.TemplateResponse(
        "export_success.html",
        {"request": request},
    )

@router.get("/test-image")
async def test_image(prompt: str = "A brave fox in an enchanted forest, comic book art"):
    try:
        path = generate_image(prompt, 0)
        return {
            "message": "Image generated successfully",
            "image_url": f"/static/panels/{path.name}",
        }
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))
