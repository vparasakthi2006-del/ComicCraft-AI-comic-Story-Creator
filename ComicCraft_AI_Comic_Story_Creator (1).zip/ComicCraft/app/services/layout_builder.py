from pathlib import Path
from typing import List
from app.models import PanelStory

def build_comic_layout(stories: List[PanelStory], image_paths: List[Path]) -> list[dict]:
    if len(stories) != len(image_paths):
        raise ValueError("Story panels and image files must have the same length.")
    layout = []
    for story, image_path in zip(stories, image_paths):
        layout.append({
            "panel_number": story.panel_number,
            "title": story.title,
            "scene_description": story.scene_description,
            "image_prompt": story.image_prompt,
            "caption": story.caption,
            "narration": story.narration,
            "dialogue": story.dialogue,
            "image_url": f"/static/panels/{image_path.name}",
            "image_path": str(image_path),
        })
    return layout
