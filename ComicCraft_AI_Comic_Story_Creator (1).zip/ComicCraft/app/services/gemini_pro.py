import json
from typing import List

from app.config import settings
from app.models import PanelOutline, PanelStory, PromptRequest

def _mock_story(req: PromptRequest, outlines: List[PanelOutline]) -> List[PanelStory]:
    result = []
    for p in outlines:
        result.append(PanelStory(
            panel_number=p.panel_number,
            title=p.title,
            scene_description=p.scene_description,
            image_prompt=p.image_prompt,
            caption=f"{req.tone.title()} moment at {req.setting}.",
            narration=(
                f"{req.character_name} takes a careful step forward. "
                f"The world around them seems to respond to the mystery in the story."
            ),
            dialogue=f"{req.character_name}: \"I have to keep going!\"",
        ))
    return result

def generate_story(req: PromptRequest, outlines: List[PanelOutline]) -> List[PanelStory]:
    if settings.mock_mode or not settings.gemini_api_key:
        return _mock_story(req, outlines)

    from google import genai
    from google.genai import types

    client = genai.Client(api_key=settings.gemini_api_key)
    outline_json = json.dumps([p.model_dump() for p in outlines], ensure_ascii=False)
    prompt = f"""
Expand this five-panel outline into a coherent comic script.

Character: {req.character_name}
Setting: {req.setting}
Tone: {req.tone}
Art style: {req.art_style}
Original idea: {req.story_prompt}

Outline:
{outline_json}

Return exactly five objects. Preserve panel_number, title, scene_description,
and image_prompt from the outline. Add caption, narration, and dialogue.
Dialogue should be short and comic-friendly. Return only JSON.
"""
    response = client.models.generate_content(
        model=settings.gemini_story_model,
        contents=prompt,
        config=types.GenerateContentConfig(
            response_mime_type="application/json",
            response_schema=list[PanelStory],
            temperature=0.85,
            max_output_tokens=4500,
        ),
    )
    data = json.loads(response.text)
    stories = [PanelStory.model_validate(item) for item in data]
    if len(stories) != 5:
        raise ValueError("Gemini did not return exactly five story panels.")
    return stories
