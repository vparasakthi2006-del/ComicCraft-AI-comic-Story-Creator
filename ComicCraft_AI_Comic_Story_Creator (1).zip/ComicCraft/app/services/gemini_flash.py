import json
from typing import List

from app.config import settings
from app.models import PanelOutline, PromptRequest

def _mock_outline(req: PromptRequest) -> List[PanelOutline]:
    return [
        PanelOutline(
            panel_number=i,
            title=t,
            scene_description=d,
            image_prompt=f"{req.art_style}, {d}, starring {req.character_name}, {req.setting}, cohesive comic panel, cinematic composition"
        )
        for i, (t, d) in enumerate([
            ("The Beginning", f"{req.character_name} arrives at {req.setting}, discovering the first clue."),
            ("A Strange Discovery", f"{req.character_name} follows the clue and encounters an unexpected mystery."),
            ("The Challenge", f"A difficult obstacle appears, forcing {req.character_name} to make a brave choice."),
            ("The Turning Point", f"{req.character_name} finds a clever solution and changes the situation."),
            ("A New Adventure", f"The mystery is resolved, leaving {req.character_name} with a hopeful new beginning."),
        ], 1)
    ]

def generate_outline(req: PromptRequest) -> List[PanelOutline]:
    if settings.mock_mode or not settings.gemini_api_key:
        return _mock_outline(req)

    from google import genai
    from google.genai import types

    client = genai.Client(api_key=settings.gemini_api_key)
    prompt = f"""
Create exactly 5 sequential comic panels for this idea.

Story prompt: {req.story_prompt}
Main character: {req.character_name}
Setting: {req.setting}
Tone: {req.tone}
Art style: {req.art_style}

Each panel must contain:
panel_number, title, scene_description, image_prompt.
Keep the same main character and visual identity across all panels.
Return only JSON matching the requested schema.
"""
    response = client.models.generate_content(
        model=settings.gemini_outline_model,
        contents=prompt,
        config=types.GenerateContentConfig(
            response_mime_type="application/json",
            response_schema=list[PanelOutline],
            temperature=0.9,
            max_output_tokens=2500,
        ),
    )
    data = json.loads(response.text)
    panels = [PanelOutline.model_validate(item) for item in data]
    if len(panels) != 5:
        raise ValueError("Gemini did not return exactly five panels.")
    return panels
