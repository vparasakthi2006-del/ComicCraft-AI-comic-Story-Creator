from pathlib import Path
from uuid import uuid4

from PIL import Image, ImageDraw, ImageFont

from app.config import settings

PANELS_DIR = Path(settings.output_dir) / "panels"
PANELS_DIR.mkdir(parents=True, exist_ok=True)

def _safe_mock_image(prompt: str, panel_number: int) -> Path:
    path = PANELS_DIR / f"panel_{panel_number}_{uuid4().hex[:8]}.png"
    img = Image.new("RGB", (settings.image_width, settings.image_height), "white")
    draw = ImageDraw.Draw(img)
    draw.rectangle((20, 20, settings.image_width-20, settings.image_height-20), outline="black", width=6)
    title = f"ComicCraft - Panel {panel_number}"
    text = prompt[:240]
    draw.text((50, 55), title, fill="black")
    # Simple wrapped text so demo mode is still visually obvious.
    y = 130
    for line in [text[i:i+55] for i in range(0, len(text), 55)]:
        draw.text((50, y), line, fill="black")
        y += 30
        if y > settings.image_height - 100:
            break
    draw.text((50, settings.image_height - 70), "Demo image - add HF_TOKEN for AI art", fill="black")
    img.save(path)
    return path

def generate_image(prompt: str, panel_number: int) -> Path:
    if settings.mock_mode or not settings.hf_api_key:
        return _safe_mock_image(prompt, panel_number)

    from huggingface_hub import InferenceClient

    client = InferenceClient(
        api_key=settings.hf_api_key,
        provider="auto",
    )
    image = client.text_to_image(
        prompt=prompt,
        model=settings.hf_image_model,
        width=settings.image_width,
        height=settings.image_height,
        num_inference_steps=settings.image_steps,
    )
    path = PANELS_DIR / f"panel_{panel_number}_{uuid4().hex[:8]}.png"
    image.save(path)
    return path
