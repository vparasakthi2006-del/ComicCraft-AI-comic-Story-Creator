from pathlib import Path
from uuid import uuid4

from fpdf import FPDF

from app.config import settings

EXPORT_DIR = Path(settings.output_dir) / "exports"
EXPORT_DIR.mkdir(parents=True, exist_ok=True)

def _latin_safe(text: str) -> str:
    return text.encode("latin-1", "replace").decode("latin-1")

def save_pdf(layout: list[dict], title: str) -> Path:
    pdf = FPDF(orientation="P", unit="mm", format="A4")
    pdf.set_auto_page_break(auto=True, margin=14)

    for panel in layout:
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 18)
        pdf.multi_cell(0, 10, _latin_safe(f"Panel {panel['panel_number']}: {panel['title']}"))
        pdf.ln(2)

        image_path = Path(panel["image_path"])
        if image_path.exists():
            pdf.image(str(image_path), x=20, y=40, w=170, h=105, keep_aspect_ratio=True)
        pdf.ln(112)

        pdf.set_font("Helvetica", "I", 11)
        pdf.multi_cell(0, 6, _latin_safe(panel["scene_description"]))
        pdf.ln(3)

        pdf.set_font("Helvetica", "B", 11)
        pdf.multi_cell(0, 6, _latin_safe("Caption: " + panel["caption"]))
        pdf.ln(2)

        pdf.set_font("Helvetica", "", 11)
        pdf.multi_cell(0, 6, _latin_safe("Narration: " + panel["narration"]))
        pdf.ln(2)
        pdf.multi_cell(0, 6, _latin_safe("Dialogue: " + panel["dialogue"]))

    filename = f"comic_{uuid4().hex[:10]}.pdf"
    output = EXPORT_DIR / filename
    pdf.output(str(output))
    return output
