# ComicCraft — AI Comic Story Creator

ComicCraft is a FastAPI web application that turns a user's story idea into a five-panel comic. It follows the project documentation workflow:

1. Collect story prompt, character, setting, tone and art style.
2. Generate a structured five-panel outline with Gemini.
3. Expand the outline into narration, captions and dialogue.
4. Generate one illustration per panel with Hugging Face text-to-image inference.
5. Build the panel layout.
6. Export the comic to PDF.
7. Preview the comic in a Jinja2 web interface.

## Important implementation note

The original documentation names older Gemini 1.5 model identifiers and the `google-generativeai` package. This implementation uses the current `google-genai` SDK and configurable model names. The model names live in `.env`, so you can change them without editing Python code.

For image generation, the app uses Hugging Face `InferenceClient`. This is the easiest way to get a working hosted diffusion-style image pipeline without forcing every VS Code machine to install a multi-GB local PyTorch stack. An optional `requirements-local-diffusers.txt` is included if you want to adapt the image service to local Diffusers later.

## 1. Open in VS Code

Extract the ZIP and open the `ComicCraft` folder in VS Code.

## 2. Create a virtual environment

Windows PowerShell:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Windows CMD:

```bat
python -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## 3. First test: demo mode

Copy `.env.example` to `.env` and leave:

```env
MOCK_MODE=true
```

Run:

```bash
uvicorn app.main:app --reload
```

Open:

- http://127.0.0.1:8000
- http://127.0.0.1:8000/docs

Demo mode creates local placeholder panel images, so you can verify the complete frontend → backend → layout → PDF pipeline without API keys.

## 4. Enable live Gemini + image generation

Put your keys into `.env`:

```env
GEMINI_API_KEY=your_gemini_key
HF_API_KEY=your_huggingface_token
MOCK_MODE=false
```

You can also change:

```env
GEMINI_OUTLINE_MODEL=gemini-3.8-flash
GEMINI_STORY_MODEL=gemini-3.8-flash
HF_IMAGE_MODEL=black-forest-labs/FLUX.1-schnell
```

Restart Uvicorn after changing `.env`.

## 5. Test the JSON API

FastAPI Swagger UI:

http://127.0.0.1:8000/docs

POST `/generate-comic/json` with:

```json
{
  "story_prompt": "A brave fox explores an enchanted forest and discovers a hidden portal.",
  "character_name": "Aria",
  "setting": "Enchanted forest",
  "tone": "Adventure",
  "art_style": "Comic book"
}
```

## 6. Test image generation separately

Open:

```text
http://127.0.0.1:8000/test-image?prompt=A%20brave%20fox%20in%20an%20enchanted%20forest
```

## 7. Project structure

```text
ComicCraft/
├── app/
│   ├── __init__.py
│   ├── main.py
│   ├── config.py
│   ├── models.py
│   ├── routes.py
│   └── services/
│       ├── __init__.py
│       ├── gemini_flash.py
│       ├── gemini_pro.py
│       ├── image_generator.py
│       ├── layout_builder.py
│       └── exporters.py
├── static/
│   ├── css/style.css
│   ├── panels/
│   └── exports/
├── templates/
│   ├── index.html
│   ├── comic_preview.html
│   └── export_success.html
├── .env.example
├── .gitignore
├── requirements.txt
├── requirements-local-diffusers.txt
└── README.md
```

## Troubleshooting

### `python` is not recognized
Install Python 3.11+ and enable "Add Python to PATH" during installation.

### PowerShell blocks activation
Use:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.venv\Scripts\Activate.ps1
```

### Gemini authentication error
Check `GEMINI_API_KEY` and make sure the configured model is available to your API project.

### Hugging Face authentication/model/provider error
Check `HF_API_KEY`, its inference permission, and the selected `HF_IMAGE_MODEL`. Hosted inference availability can vary by model/provider.

### PDF works but images are placeholders
Set `MOCK_MODE=false` and configure both API keys. In demo mode this behavior is intentional.

## Security

Never commit `.env` or expose API keys in frontend JavaScript. `.gitignore` already excludes `.env`.
